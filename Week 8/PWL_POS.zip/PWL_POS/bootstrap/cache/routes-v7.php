<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/sanctum/csrf-cookie' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sanctum.csrf-cookie',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/health-check' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.healthCheck',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/execute-solution' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.executeSolution',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/update-config' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.updateConfig',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lCVBlv2ND2spVrc2',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ALNkO4rxzXWlhr4K',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GOz1BHIb7FTAdQqw',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/register' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'register',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JXQk2VeOw54KRfW4',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::em0uRvVm0lGabVc2',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/update-photo' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Cu7cZ6HCxxfBpbt2',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/delete-photo' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PKRhGW7eY16oM9a1',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Gq6RMs55838Neai6',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QoPDDJ4HuscoX0JI',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/list' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kkANfKi1uSiExLeY',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LNHPQ0oRr2KwLI3b',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/create_ajax' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Z69OMl1YJraD7tt8',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/ajax' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ycVv1EzrV1gMg0Oa',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/import' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QWQf879oOKusZX7Q',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/import_ajax' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ccsd9jNRg52ZKdgs',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/export_excel' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ePa3T1K7kOnN2SYm',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/export_pdf' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::txiF40SrLrUZPiTc',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/level' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xpY3aTP1a6Jhyjnr',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::z2Twn6UK9GZv41b4',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/level/list' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ph776RiN55NDIzwD',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/level/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PwZ6LFXpdDw8QzW9',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/level/create_ajax' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EWFq215eCuYfzsjj',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/level/ajax' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tO5aJec3e2765SlW',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/level/import' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::M9A2RIsvP0bOsugA',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/level/import_ajax' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KMm7P0AQSgeqtEEq',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/level/export_excel' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3CvuCKiTWLZ6zOTh',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/level/export_pdf' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yfqKxdcNG4PLVRCl',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/kategori' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ziv0MhLcphoQJgij',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5eLU3dGpd7H1x1dZ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/kategori/list' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UhrPhsonXxoD8jU2',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/kategori/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2C9SnBX5L5I7Wbpz',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/kategori/create_ajax' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GssgGrl6t8KmYYyi',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/kategori/ajax' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8t6qgA8PSRv9Xqzq',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/kategori/import' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6q0WX2vDB3qCxYUX',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/kategori/import_ajax' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lry29yyhYncpzVle',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/kategori/export_excel' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7aYGbTYu7xt6f4Pt',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/kategori/export_pdf' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::eclK5WnqG1o1WvYR',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/barang' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CIaglsqjlIQeWpWj',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rWZllUkfgNKJxb1A',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/barang/list' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::q62ggXV7RmG37pMi',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/barang/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HrChS5KdQ5cQofPS',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/barang/create_ajax' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FseoDlcwFViBUHAH',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/barang/ajax' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xBg5d9cduEvQlleL',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/barang/import' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nVvxWcju2IqaGpCy',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/barang/import_ajax' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mhgusUAta7omyGdw',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/barang/export_excel' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HrDTVq8GcEt2bx4K',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/barang/export_pdf' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rIp1zN1bVmz3vVPs',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/supplier' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UcWpyPDslAbzo5tb',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7ordzTq8KowYzZae',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/supplier/list' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4Lh9PZwL1h4x5iLw',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/supplier/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RG94TcjqCTkO2yrl',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/supplier/create_ajax' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7OokbZzoIdjroTlO',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/supplier/ajax' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::leykZ2qOTLNjFiGL',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/supplier/import' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oyTbm7rHv08IYBgU',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/supplier/import_ajax' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::urgURUNRiYOsupLm',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/supplier/export_excel' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::J1NzvJ7GLds0C133',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/supplier/export_pdf' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wj7wGAQPknYaxIa8',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/user/(?|([0-9]+)(*:24)|([0-9]+)/edit(*:44)|([0-9]+)(*:59)|([0-9]+)/edit_ajax(*:84)|([0-9]+)/update_ajax(*:111)|([0-9]+)/delete_ajax(?|(*:142))|([0-9]+)(*:159))|/level/(?|([0-9]+)(*:186)|([0-9]+)/edit(*:207)|([0-9]+)(*:223)|([0-9]+)/edit_ajax(*:249)|([0-9]+)/update_ajax(*:277)|([0-9]+)/delete_ajax(?|(*:308))|([0-9]+)(*:325))|/kategori/(?|([0-9]+)(*:355)|([0-9]+)/edit(*:376)|([0-9]+)(*:392)|([0-9]+)/edit_ajax(*:418)|([0-9]+)/update_ajax(*:446)|([0-9]+)/delete_ajax(?|(*:477))|([0-9]+)(*:494))|/barang/(?|([0-9]+)(*:522)|([0-9]+)/edit(*:543)|([0-9]+)(*:559)|([0-9]+)/edit_ajax(*:585)|([0-9]+)/update_ajax(*:613)|([0-9]+)/delete_ajax(?|(*:644))|([0-9]+)(*:661))|/supplier/(?|([0-9]+)(*:691)|([0-9]+)/edit(*:712)|([0-9]+)(*:728)|([0-9]+)/edit_ajax(*:754)|([0-9]+)/update_ajax(*:782)|([0-9]+)/delete_ajax(?|(*:813))|([0-9]+)(*:830)))/?$}sDu',
    ),
    3 => 
    array (
      24 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::riNO0EAFuVXEI1jd',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      44 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5h3qxZU7irFzXalq',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      59 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Bls9TBaIlCi6K20O',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      84 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZzuyJgwPhhfHpLGI',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      111 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nfGXaeZBYc5P1400',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      142 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MUx92o9AkAwlnFoT',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2w8r5X5IMq3O9VPY',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      159 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xLaCDvC5l57xZK7s',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      186 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uu8keJEmPTRtyjJh',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      207 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KQRWutb8rd7oWSex',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      223 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7M83g4p5mrgmoAIX',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      249 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1LNSDVrWyel9Jtar',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      277 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::A4wXSqidityemQtJ',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      308 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ds0EAPZwXORBTDnW',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wfk0oYuw0QKLLn7H',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      325 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hukhvGcaOQhpCVxO',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      355 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gaDZ04xEzgUFlmdH',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      376 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kG5nDkA0ccqV5m1l',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      392 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OgLWoMGPGnN5jQQ0',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      418 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZurlHegzX8uZ50fx',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      446 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ghmGZXKMYXDe6nbh',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      477 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::eV2YU7LFmkwbryxd',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CUzpzHM9hJp51hST',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      494 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kiz4beBiqyhBDwMJ',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      522 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MAIEfsQooHw0hwGC',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      543 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::L45LnryZQJyP9t0Y',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      559 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4uDgPZx8IuvBopHV',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      585 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RiKzABtrj5Fu6VBm',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      613 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::e1xlgHguR4UAceqr',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      644 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rmuikaJybCoWfiKi',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GK1emzphgqSWAXBw',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      661 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0NsCcyKDrBCXDG0J',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      691 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GQBX8KBvpLLReGDU',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      712 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BrKzIYqHZqVRcP0o',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      728 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GVFQu6TyrfH918ho',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      754 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VAF8v3Vm8zKmTFAu',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      782 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xnwxvBT5aVcLGWTY',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      813 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gQ6QvsZWwMmHzHQs',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2wbvypYudhg2URGM',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      830 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::eaqELzAlcpZqXzj5',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'sanctum.csrf-cookie' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sanctum/csrf-cookie',
      'action' => 
      array (
        'uses' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'controller' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'namespace' => NULL,
        'prefix' => 'sanctum',
        'where' => 
        array (
        ),
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'sanctum.csrf-cookie',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.healthCheck' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '_ignition/health-check',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\HealthCheckController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\HealthCheckController',
        'as' => 'ignition.healthCheck',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.executeSolution' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '_ignition/execute-solution',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\ExecuteSolutionController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\ExecuteSolutionController',
        'as' => 'ignition.executeSolution',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.updateConfig' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '_ignition/update-config',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\UpdateConfigController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\UpdateConfigController',
        'as' => 'ignition.updateConfig',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lCVBlv2ND2spVrc2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:77:"function (\\Illuminate\\Http\\Request $request) {
    return $request->user();
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000003a40000000000000000";}}',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::lCVBlv2ND2spVrc2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@login',
        'controller' => 'App\\Http\\Controllers\\AuthController@login',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ALNkO4rxzXWlhr4K' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@postlogin',
        'controller' => 'App\\Http\\Controllers\\AuthController@postlogin',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::ALNkO4rxzXWlhr4K',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::GOz1BHIb7FTAdQqw' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@logout',
        'controller' => 'App\\Http\\Controllers\\AuthController@logout',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::GOz1BHIb7FTAdQqw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'register' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'register',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@register',
        'controller' => 'App\\Http\\Controllers\\AuthController@register',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'register',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::JXQk2VeOw54KRfW4' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'register',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@store_user',
        'controller' => 'App\\Http\\Controllers\\AuthController@store_user',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::JXQk2VeOw54KRfW4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::em0uRvVm0lGabVc2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\WelcomeController@index',
        'controller' => 'App\\Http\\Controllers\\WelcomeController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::em0uRvVm0lGabVc2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Cu7cZ6HCxxfBpbt2' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'update-photo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@update_photo',
        'controller' => 'App\\Http\\Controllers\\UserController@update_photo',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Cu7cZ6HCxxfBpbt2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::PKRhGW7eY16oM9a1' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'delete-photo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@delete_photo',
        'controller' => 'App\\Http\\Controllers\\UserController@delete_photo',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::PKRhGW7eY16oM9a1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Gq6RMs55838Neai6' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@index',
        'controller' => 'App\\Http\\Controllers\\UserController@index',
        'namespace' => NULL,
        'prefix' => '/user',
        'where' => 
        array (
        ),
        'as' => 'generated::Gq6RMs55838Neai6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::kkANfKi1uSiExLeY' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'user/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@list',
        'controller' => 'App\\Http\\Controllers\\UserController@list',
        'namespace' => NULL,
        'prefix' => '/user',
        'where' => 
        array (
        ),
        'as' => 'generated::kkANfKi1uSiExLeY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LNHPQ0oRr2KwLI3b' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@create',
        'controller' => 'App\\Http\\Controllers\\UserController@create',
        'namespace' => NULL,
        'prefix' => '/user',
        'where' => 
        array (
        ),
        'as' => 'generated::LNHPQ0oRr2KwLI3b',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QoPDDJ4HuscoX0JI' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@store',
        'controller' => 'App\\Http\\Controllers\\UserController@store',
        'namespace' => NULL,
        'prefix' => '/user',
        'where' => 
        array (
        ),
        'as' => 'generated::QoPDDJ4HuscoX0JI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Z69OMl1YJraD7tt8' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/create_ajax',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@create_ajax',
        'controller' => 'App\\Http\\Controllers\\UserController@create_ajax',
        'namespace' => NULL,
        'prefix' => '/user',
        'where' => 
        array (
        ),
        'as' => 'generated::Z69OMl1YJraD7tt8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ycVv1EzrV1gMg0Oa' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'user/ajax',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@store_ajax',
        'controller' => 'App\\Http\\Controllers\\UserController@store_ajax',
        'namespace' => NULL,
        'prefix' => '/user',
        'where' => 
        array (
        ),
        'as' => 'generated::ycVv1EzrV1gMg0Oa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::riNO0EAFuVXEI1jd' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@show',
        'controller' => 'App\\Http\\Controllers\\UserController@show',
        'namespace' => NULL,
        'prefix' => '/user',
        'where' => 
        array (
        ),
        'as' => 'generated::riNO0EAFuVXEI1jd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5h3qxZU7irFzXalq' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/{id}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@edit',
        'controller' => 'App\\Http\\Controllers\\UserController@edit',
        'namespace' => NULL,
        'prefix' => '/user',
        'where' => 
        array (
        ),
        'as' => 'generated::5h3qxZU7irFzXalq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Bls9TBaIlCi6K20O' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'user/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@update',
        'controller' => 'App\\Http\\Controllers\\UserController@update',
        'namespace' => NULL,
        'prefix' => '/user',
        'where' => 
        array (
        ),
        'as' => 'generated::Bls9TBaIlCi6K20O',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZzuyJgwPhhfHpLGI' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/{id}/edit_ajax',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@edit_ajax',
        'controller' => 'App\\Http\\Controllers\\UserController@edit_ajax',
        'namespace' => NULL,
        'prefix' => '/user',
        'where' => 
        array (
        ),
        'as' => 'generated::ZzuyJgwPhhfHpLGI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::nfGXaeZBYc5P1400' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'user/{id}/update_ajax',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@update_ajax',
        'controller' => 'App\\Http\\Controllers\\UserController@update_ajax',
        'namespace' => NULL,
        'prefix' => '/user',
        'where' => 
        array (
        ),
        'as' => 'generated::nfGXaeZBYc5P1400',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MUx92o9AkAwlnFoT' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/{id}/delete_ajax',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@confirm_ajax',
        'controller' => 'App\\Http\\Controllers\\UserController@confirm_ajax',
        'namespace' => NULL,
        'prefix' => '/user',
        'where' => 
        array (
        ),
        'as' => 'generated::MUx92o9AkAwlnFoT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2w8r5X5IMq3O9VPY' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'user/{id}/delete_ajax',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@delete_ajax',
        'controller' => 'App\\Http\\Controllers\\UserController@delete_ajax',
        'namespace' => NULL,
        'prefix' => '/user',
        'where' => 
        array (
        ),
        'as' => 'generated::2w8r5X5IMq3O9VPY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xLaCDvC5l57xZK7s' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'user/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@destroy',
        'controller' => 'App\\Http\\Controllers\\UserController@destroy',
        'namespace' => NULL,
        'prefix' => '/user',
        'where' => 
        array (
        ),
        'as' => 'generated::xLaCDvC5l57xZK7s',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QWQf879oOKusZX7Q' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/import',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@import',
        'controller' => 'App\\Http\\Controllers\\UserController@import',
        'namespace' => NULL,
        'prefix' => '/user',
        'where' => 
        array (
        ),
        'as' => 'generated::QWQf879oOKusZX7Q',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ccsd9jNRg52ZKdgs' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'user/import_ajax',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@import_ajax',
        'controller' => 'App\\Http\\Controllers\\UserController@import_ajax',
        'namespace' => NULL,
        'prefix' => '/user',
        'where' => 
        array (
        ),
        'as' => 'generated::ccsd9jNRg52ZKdgs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ePa3T1K7kOnN2SYm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/export_excel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@export_excel',
        'controller' => 'App\\Http\\Controllers\\UserController@export_excel',
        'namespace' => NULL,
        'prefix' => '/user',
        'where' => 
        array (
        ),
        'as' => 'generated::ePa3T1K7kOnN2SYm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::txiF40SrLrUZPiTc' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/export_pdf',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@export_pdf',
        'controller' => 'App\\Http\\Controllers\\UserController@export_pdf',
        'namespace' => NULL,
        'prefix' => '/user',
        'where' => 
        array (
        ),
        'as' => 'generated::txiF40SrLrUZPiTc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xpY3aTP1a6Jhyjnr' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'level',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\LevelController@index',
        'controller' => 'App\\Http\\Controllers\\LevelController@index',
        'namespace' => NULL,
        'prefix' => '/level',
        'where' => 
        array (
        ),
        'as' => 'generated::xpY3aTP1a6Jhyjnr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ph776RiN55NDIzwD' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'level/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\LevelController@list',
        'controller' => 'App\\Http\\Controllers\\LevelController@list',
        'namespace' => NULL,
        'prefix' => '/level',
        'where' => 
        array (
        ),
        'as' => 'generated::ph776RiN55NDIzwD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::PwZ6LFXpdDw8QzW9' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'level/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\LevelController@create',
        'controller' => 'App\\Http\\Controllers\\LevelController@create',
        'namespace' => NULL,
        'prefix' => '/level',
        'where' => 
        array (
        ),
        'as' => 'generated::PwZ6LFXpdDw8QzW9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::z2Twn6UK9GZv41b4' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'level',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\LevelController@store',
        'controller' => 'App\\Http\\Controllers\\LevelController@store',
        'namespace' => NULL,
        'prefix' => '/level',
        'where' => 
        array (
        ),
        'as' => 'generated::z2Twn6UK9GZv41b4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::EWFq215eCuYfzsjj' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'level/create_ajax',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\LevelController@create_ajax',
        'controller' => 'App\\Http\\Controllers\\LevelController@create_ajax',
        'namespace' => NULL,
        'prefix' => '/level',
        'where' => 
        array (
        ),
        'as' => 'generated::EWFq215eCuYfzsjj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::tO5aJec3e2765SlW' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'level/ajax',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\LevelController@store_ajax',
        'controller' => 'App\\Http\\Controllers\\LevelController@store_ajax',
        'namespace' => NULL,
        'prefix' => '/level',
        'where' => 
        array (
        ),
        'as' => 'generated::tO5aJec3e2765SlW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::uu8keJEmPTRtyjJh' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'level/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\LevelController@show',
        'controller' => 'App\\Http\\Controllers\\LevelController@show',
        'namespace' => NULL,
        'prefix' => '/level',
        'where' => 
        array (
        ),
        'as' => 'generated::uu8keJEmPTRtyjJh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::KQRWutb8rd7oWSex' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'level/{id}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\LevelController@edit',
        'controller' => 'App\\Http\\Controllers\\LevelController@edit',
        'namespace' => NULL,
        'prefix' => '/level',
        'where' => 
        array (
        ),
        'as' => 'generated::KQRWutb8rd7oWSex',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7M83g4p5mrgmoAIX' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'level/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\LevelController@update',
        'controller' => 'App\\Http\\Controllers\\LevelController@update',
        'namespace' => NULL,
        'prefix' => '/level',
        'where' => 
        array (
        ),
        'as' => 'generated::7M83g4p5mrgmoAIX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1LNSDVrWyel9Jtar' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'level/{id}/edit_ajax',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\LevelController@edit_ajax',
        'controller' => 'App\\Http\\Controllers\\LevelController@edit_ajax',
        'namespace' => NULL,
        'prefix' => '/level',
        'where' => 
        array (
        ),
        'as' => 'generated::1LNSDVrWyel9Jtar',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::A4wXSqidityemQtJ' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'level/{id}/update_ajax',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\LevelController@update_ajax',
        'controller' => 'App\\Http\\Controllers\\LevelController@update_ajax',
        'namespace' => NULL,
        'prefix' => '/level',
        'where' => 
        array (
        ),
        'as' => 'generated::A4wXSqidityemQtJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ds0EAPZwXORBTDnW' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'level/{id}/delete_ajax',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\LevelController@confirm_ajax',
        'controller' => 'App\\Http\\Controllers\\LevelController@confirm_ajax',
        'namespace' => NULL,
        'prefix' => '/level',
        'where' => 
        array (
        ),
        'as' => 'generated::ds0EAPZwXORBTDnW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wfk0oYuw0QKLLn7H' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'level/{id}/delete_ajax',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\LevelController@delete_ajax',
        'controller' => 'App\\Http\\Controllers\\LevelController@delete_ajax',
        'namespace' => NULL,
        'prefix' => '/level',
        'where' => 
        array (
        ),
        'as' => 'generated::wfk0oYuw0QKLLn7H',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hukhvGcaOQhpCVxO' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'level/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\LevelController@destroy',
        'controller' => 'App\\Http\\Controllers\\LevelController@destroy',
        'namespace' => NULL,
        'prefix' => '/level',
        'where' => 
        array (
        ),
        'as' => 'generated::hukhvGcaOQhpCVxO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::M9A2RIsvP0bOsugA' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'level/import',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\LevelController@import',
        'controller' => 'App\\Http\\Controllers\\LevelController@import',
        'namespace' => NULL,
        'prefix' => '/level',
        'where' => 
        array (
        ),
        'as' => 'generated::M9A2RIsvP0bOsugA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::KMm7P0AQSgeqtEEq' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'level/import_ajax',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\LevelController@import_ajax',
        'controller' => 'App\\Http\\Controllers\\LevelController@import_ajax',
        'namespace' => NULL,
        'prefix' => '/level',
        'where' => 
        array (
        ),
        'as' => 'generated::KMm7P0AQSgeqtEEq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3CvuCKiTWLZ6zOTh' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'level/export_excel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\LevelController@export_excel',
        'controller' => 'App\\Http\\Controllers\\LevelController@export_excel',
        'namespace' => NULL,
        'prefix' => '/level',
        'where' => 
        array (
        ),
        'as' => 'generated::3CvuCKiTWLZ6zOTh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::yfqKxdcNG4PLVRCl' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'level/export_pdf',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\LevelController@export_pdf',
        'controller' => 'App\\Http\\Controllers\\LevelController@export_pdf',
        'namespace' => NULL,
        'prefix' => '/level',
        'where' => 
        array (
        ),
        'as' => 'generated::yfqKxdcNG4PLVRCl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ziv0MhLcphoQJgij' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kategori',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM,MNG',
        ),
        'uses' => 'App\\Http\\Controllers\\KategoriController@index',
        'controller' => 'App\\Http\\Controllers\\KategoriController@index',
        'namespace' => NULL,
        'prefix' => '/kategori',
        'where' => 
        array (
        ),
        'as' => 'generated::ziv0MhLcphoQJgij',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::UhrPhsonXxoD8jU2' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'kategori/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM,MNG',
        ),
        'uses' => 'App\\Http\\Controllers\\KategoriController@list',
        'controller' => 'App\\Http\\Controllers\\KategoriController@list',
        'namespace' => NULL,
        'prefix' => '/kategori',
        'where' => 
        array (
        ),
        'as' => 'generated::UhrPhsonXxoD8jU2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2C9SnBX5L5I7Wbpz' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kategori/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM,MNG',
        ),
        'uses' => 'App\\Http\\Controllers\\KategoriController@create',
        'controller' => 'App\\Http\\Controllers\\KategoriController@create',
        'namespace' => NULL,
        'prefix' => '/kategori',
        'where' => 
        array (
        ),
        'as' => 'generated::2C9SnBX5L5I7Wbpz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5eLU3dGpd7H1x1dZ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'kategori',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM,MNG',
        ),
        'uses' => 'App\\Http\\Controllers\\KategoriController@store',
        'controller' => 'App\\Http\\Controllers\\KategoriController@store',
        'namespace' => NULL,
        'prefix' => '/kategori',
        'where' => 
        array (
        ),
        'as' => 'generated::5eLU3dGpd7H1x1dZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::GssgGrl6t8KmYYyi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kategori/create_ajax',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM,MNG',
        ),
        'uses' => 'App\\Http\\Controllers\\KategoriController@create_ajax',
        'controller' => 'App\\Http\\Controllers\\KategoriController@create_ajax',
        'namespace' => NULL,
        'prefix' => '/kategori',
        'where' => 
        array (
        ),
        'as' => 'generated::GssgGrl6t8KmYYyi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8t6qgA8PSRv9Xqzq' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'kategori/ajax',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM,MNG',
        ),
        'uses' => 'App\\Http\\Controllers\\KategoriController@store_ajax',
        'controller' => 'App\\Http\\Controllers\\KategoriController@store_ajax',
        'namespace' => NULL,
        'prefix' => '/kategori',
        'where' => 
        array (
        ),
        'as' => 'generated::8t6qgA8PSRv9Xqzq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gaDZ04xEzgUFlmdH' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kategori/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM,MNG',
        ),
        'uses' => 'App\\Http\\Controllers\\KategoriController@show',
        'controller' => 'App\\Http\\Controllers\\KategoriController@show',
        'namespace' => NULL,
        'prefix' => '/kategori',
        'where' => 
        array (
        ),
        'as' => 'generated::gaDZ04xEzgUFlmdH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::kG5nDkA0ccqV5m1l' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kategori/{id}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM,MNG',
        ),
        'uses' => 'App\\Http\\Controllers\\KategoriController@edit',
        'controller' => 'App\\Http\\Controllers\\KategoriController@edit',
        'namespace' => NULL,
        'prefix' => '/kategori',
        'where' => 
        array (
        ),
        'as' => 'generated::kG5nDkA0ccqV5m1l',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OgLWoMGPGnN5jQQ0' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'kategori/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM,MNG',
        ),
        'uses' => 'App\\Http\\Controllers\\KategoriController@update',
        'controller' => 'App\\Http\\Controllers\\KategoriController@update',
        'namespace' => NULL,
        'prefix' => '/kategori',
        'where' => 
        array (
        ),
        'as' => 'generated::OgLWoMGPGnN5jQQ0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZurlHegzX8uZ50fx' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kategori/{id}/edit_ajax',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM,MNG',
        ),
        'uses' => 'App\\Http\\Controllers\\KategoriController@edit_ajax',
        'controller' => 'App\\Http\\Controllers\\KategoriController@edit_ajax',
        'namespace' => NULL,
        'prefix' => '/kategori',
        'where' => 
        array (
        ),
        'as' => 'generated::ZurlHegzX8uZ50fx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ghmGZXKMYXDe6nbh' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'kategori/{id}/update_ajax',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM,MNG',
        ),
        'uses' => 'App\\Http\\Controllers\\KategoriController@update_ajax',
        'controller' => 'App\\Http\\Controllers\\KategoriController@update_ajax',
        'namespace' => NULL,
        'prefix' => '/kategori',
        'where' => 
        array (
        ),
        'as' => 'generated::ghmGZXKMYXDe6nbh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::eV2YU7LFmkwbryxd' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kategori/{id}/delete_ajax',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM,MNG',
        ),
        'uses' => 'App\\Http\\Controllers\\KategoriController@confirm_ajax',
        'controller' => 'App\\Http\\Controllers\\KategoriController@confirm_ajax',
        'namespace' => NULL,
        'prefix' => '/kategori',
        'where' => 
        array (
        ),
        'as' => 'generated::eV2YU7LFmkwbryxd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CUzpzHM9hJp51hST' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'kategori/{id}/delete_ajax',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM,MNG',
        ),
        'uses' => 'App\\Http\\Controllers\\KategoriController@delete_ajax',
        'controller' => 'App\\Http\\Controllers\\KategoriController@delete_ajax',
        'namespace' => NULL,
        'prefix' => '/kategori',
        'where' => 
        array (
        ),
        'as' => 'generated::CUzpzHM9hJp51hST',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::kiz4beBiqyhBDwMJ' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'kategori/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM,MNG',
        ),
        'uses' => 'App\\Http\\Controllers\\KategoriController@destroy',
        'controller' => 'App\\Http\\Controllers\\KategoriController@destroy',
        'namespace' => NULL,
        'prefix' => '/kategori',
        'where' => 
        array (
        ),
        'as' => 'generated::kiz4beBiqyhBDwMJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6q0WX2vDB3qCxYUX' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kategori/import',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM,MNG',
        ),
        'uses' => 'App\\Http\\Controllers\\KategoriController@import',
        'controller' => 'App\\Http\\Controllers\\KategoriController@import',
        'namespace' => NULL,
        'prefix' => '/kategori',
        'where' => 
        array (
        ),
        'as' => 'generated::6q0WX2vDB3qCxYUX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lry29yyhYncpzVle' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'kategori/import_ajax',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM,MNG',
        ),
        'uses' => 'App\\Http\\Controllers\\KategoriController@import_ajax',
        'controller' => 'App\\Http\\Controllers\\KategoriController@import_ajax',
        'namespace' => NULL,
        'prefix' => '/kategori',
        'where' => 
        array (
        ),
        'as' => 'generated::lry29yyhYncpzVle',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7aYGbTYu7xt6f4Pt' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kategori/export_excel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM,MNG',
        ),
        'uses' => 'App\\Http\\Controllers\\KategoriController@export_excel',
        'controller' => 'App\\Http\\Controllers\\KategoriController@export_excel',
        'namespace' => NULL,
        'prefix' => '/kategori',
        'where' => 
        array (
        ),
        'as' => 'generated::7aYGbTYu7xt6f4Pt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::eclK5WnqG1o1WvYR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'kategori/export_pdf',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM,MNG',
        ),
        'uses' => 'App\\Http\\Controllers\\KategoriController@export_pdf',
        'controller' => 'App\\Http\\Controllers\\KategoriController@export_pdf',
        'namespace' => NULL,
        'prefix' => '/kategori',
        'where' => 
        array (
        ),
        'as' => 'generated::eclK5WnqG1o1WvYR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CIaglsqjlIQeWpWj' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'barang',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM,MNG',
        ),
        'uses' => 'App\\Http\\Controllers\\BarangController@index',
        'controller' => 'App\\Http\\Controllers\\BarangController@index',
        'namespace' => NULL,
        'prefix' => '/barang',
        'where' => 
        array (
        ),
        'as' => 'generated::CIaglsqjlIQeWpWj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::q62ggXV7RmG37pMi' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'barang/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM,MNG',
        ),
        'uses' => 'App\\Http\\Controllers\\BarangController@list',
        'controller' => 'App\\Http\\Controllers\\BarangController@list',
        'namespace' => NULL,
        'prefix' => '/barang',
        'where' => 
        array (
        ),
        'as' => 'generated::q62ggXV7RmG37pMi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HrChS5KdQ5cQofPS' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'barang/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM,MNG',
        ),
        'uses' => 'App\\Http\\Controllers\\BarangController@create',
        'controller' => 'App\\Http\\Controllers\\BarangController@create',
        'namespace' => NULL,
        'prefix' => '/barang',
        'where' => 
        array (
        ),
        'as' => 'generated::HrChS5KdQ5cQofPS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rWZllUkfgNKJxb1A' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'barang',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM,MNG',
        ),
        'uses' => 'App\\Http\\Controllers\\BarangController@store',
        'controller' => 'App\\Http\\Controllers\\BarangController@store',
        'namespace' => NULL,
        'prefix' => '/barang',
        'where' => 
        array (
        ),
        'as' => 'generated::rWZllUkfgNKJxb1A',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::FseoDlcwFViBUHAH' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'barang/create_ajax',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM,MNG',
        ),
        'uses' => 'App\\Http\\Controllers\\BarangController@create_ajax',
        'controller' => 'App\\Http\\Controllers\\BarangController@create_ajax',
        'namespace' => NULL,
        'prefix' => '/barang',
        'where' => 
        array (
        ),
        'as' => 'generated::FseoDlcwFViBUHAH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xBg5d9cduEvQlleL' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'barang/ajax',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM,MNG',
        ),
        'uses' => 'App\\Http\\Controllers\\BarangController@store_ajax',
        'controller' => 'App\\Http\\Controllers\\BarangController@store_ajax',
        'namespace' => NULL,
        'prefix' => '/barang',
        'where' => 
        array (
        ),
        'as' => 'generated::xBg5d9cduEvQlleL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MAIEfsQooHw0hwGC' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'barang/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM,MNG',
        ),
        'uses' => 'App\\Http\\Controllers\\BarangController@show',
        'controller' => 'App\\Http\\Controllers\\BarangController@show',
        'namespace' => NULL,
        'prefix' => '/barang',
        'where' => 
        array (
        ),
        'as' => 'generated::MAIEfsQooHw0hwGC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::L45LnryZQJyP9t0Y' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'barang/{id}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM,MNG',
        ),
        'uses' => 'App\\Http\\Controllers\\BarangController@edit',
        'controller' => 'App\\Http\\Controllers\\BarangController@edit',
        'namespace' => NULL,
        'prefix' => '/barang',
        'where' => 
        array (
        ),
        'as' => 'generated::L45LnryZQJyP9t0Y',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4uDgPZx8IuvBopHV' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'barang/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM,MNG',
        ),
        'uses' => 'App\\Http\\Controllers\\BarangController@update',
        'controller' => 'App\\Http\\Controllers\\BarangController@update',
        'namespace' => NULL,
        'prefix' => '/barang',
        'where' => 
        array (
        ),
        'as' => 'generated::4uDgPZx8IuvBopHV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RiKzABtrj5Fu6VBm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'barang/{id}/edit_ajax',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM,MNG',
        ),
        'uses' => 'App\\Http\\Controllers\\BarangController@edit_ajax',
        'controller' => 'App\\Http\\Controllers\\BarangController@edit_ajax',
        'namespace' => NULL,
        'prefix' => '/barang',
        'where' => 
        array (
        ),
        'as' => 'generated::RiKzABtrj5Fu6VBm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::e1xlgHguR4UAceqr' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'barang/{id}/update_ajax',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM,MNG',
        ),
        'uses' => 'App\\Http\\Controllers\\BarangController@update_ajax',
        'controller' => 'App\\Http\\Controllers\\BarangController@update_ajax',
        'namespace' => NULL,
        'prefix' => '/barang',
        'where' => 
        array (
        ),
        'as' => 'generated::e1xlgHguR4UAceqr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rmuikaJybCoWfiKi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'barang/{id}/delete_ajax',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM,MNG',
        ),
        'uses' => 'App\\Http\\Controllers\\BarangController@confirm_ajax',
        'controller' => 'App\\Http\\Controllers\\BarangController@confirm_ajax',
        'namespace' => NULL,
        'prefix' => '/barang',
        'where' => 
        array (
        ),
        'as' => 'generated::rmuikaJybCoWfiKi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::GK1emzphgqSWAXBw' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'barang/{id}/delete_ajax',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM,MNG',
        ),
        'uses' => 'App\\Http\\Controllers\\BarangController@delete_ajax',
        'controller' => 'App\\Http\\Controllers\\BarangController@delete_ajax',
        'namespace' => NULL,
        'prefix' => '/barang',
        'where' => 
        array (
        ),
        'as' => 'generated::GK1emzphgqSWAXBw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0NsCcyKDrBCXDG0J' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'barang/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM,MNG',
        ),
        'uses' => 'App\\Http\\Controllers\\BarangController@destroy',
        'controller' => 'App\\Http\\Controllers\\BarangController@destroy',
        'namespace' => NULL,
        'prefix' => '/barang',
        'where' => 
        array (
        ),
        'as' => 'generated::0NsCcyKDrBCXDG0J',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::nVvxWcju2IqaGpCy' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'barang/import',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM,MNG',
        ),
        'uses' => 'App\\Http\\Controllers\\BarangController@import',
        'controller' => 'App\\Http\\Controllers\\BarangController@import',
        'namespace' => NULL,
        'prefix' => '/barang',
        'where' => 
        array (
        ),
        'as' => 'generated::nVvxWcju2IqaGpCy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mhgusUAta7omyGdw' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'barang/import_ajax',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM,MNG',
        ),
        'uses' => 'App\\Http\\Controllers\\BarangController@import_ajax',
        'controller' => 'App\\Http\\Controllers\\BarangController@import_ajax',
        'namespace' => NULL,
        'prefix' => '/barang',
        'where' => 
        array (
        ),
        'as' => 'generated::mhgusUAta7omyGdw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HrDTVq8GcEt2bx4K' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'barang/export_excel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM,MNG',
        ),
        'uses' => 'App\\Http\\Controllers\\BarangController@export_excel',
        'controller' => 'App\\Http\\Controllers\\BarangController@export_excel',
        'namespace' => NULL,
        'prefix' => '/barang',
        'where' => 
        array (
        ),
        'as' => 'generated::HrDTVq8GcEt2bx4K',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rIp1zN1bVmz3vVPs' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'barang/export_pdf',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:ADM,MNG',
        ),
        'uses' => 'App\\Http\\Controllers\\BarangController@export_pdf',
        'controller' => 'App\\Http\\Controllers\\BarangController@export_pdf',
        'namespace' => NULL,
        'prefix' => '/barang',
        'where' => 
        array (
        ),
        'as' => 'generated::rIp1zN1bVmz3vVPs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::UcWpyPDslAbzo5tb' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'supplier',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:MNG,ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\SupplierController@index',
        'controller' => 'App\\Http\\Controllers\\SupplierController@index',
        'namespace' => NULL,
        'prefix' => '/supplier',
        'where' => 
        array (
        ),
        'as' => 'generated::UcWpyPDslAbzo5tb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4Lh9PZwL1h4x5iLw' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'supplier/list',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:MNG,ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\SupplierController@list',
        'controller' => 'App\\Http\\Controllers\\SupplierController@list',
        'namespace' => NULL,
        'prefix' => '/supplier',
        'where' => 
        array (
        ),
        'as' => 'generated::4Lh9PZwL1h4x5iLw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RG94TcjqCTkO2yrl' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'supplier/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:MNG,ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\SupplierController@create',
        'controller' => 'App\\Http\\Controllers\\SupplierController@create',
        'namespace' => NULL,
        'prefix' => '/supplier',
        'where' => 
        array (
        ),
        'as' => 'generated::RG94TcjqCTkO2yrl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7ordzTq8KowYzZae' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'supplier',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:MNG,ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\SupplierController@store',
        'controller' => 'App\\Http\\Controllers\\SupplierController@store',
        'namespace' => NULL,
        'prefix' => '/supplier',
        'where' => 
        array (
        ),
        'as' => 'generated::7ordzTq8KowYzZae',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7OokbZzoIdjroTlO' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'supplier/create_ajax',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:MNG,ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\SupplierController@create_ajax',
        'controller' => 'App\\Http\\Controllers\\SupplierController@create_ajax',
        'namespace' => NULL,
        'prefix' => '/supplier',
        'where' => 
        array (
        ),
        'as' => 'generated::7OokbZzoIdjroTlO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::leykZ2qOTLNjFiGL' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'supplier/ajax',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:MNG,ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\SupplierController@store_ajax',
        'controller' => 'App\\Http\\Controllers\\SupplierController@store_ajax',
        'namespace' => NULL,
        'prefix' => '/supplier',
        'where' => 
        array (
        ),
        'as' => 'generated::leykZ2qOTLNjFiGL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::GQBX8KBvpLLReGDU' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'supplier/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:MNG,ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\SupplierController@show',
        'controller' => 'App\\Http\\Controllers\\SupplierController@show',
        'namespace' => NULL,
        'prefix' => '/supplier',
        'where' => 
        array (
        ),
        'as' => 'generated::GQBX8KBvpLLReGDU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::BrKzIYqHZqVRcP0o' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'supplier/{id}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:MNG,ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\SupplierController@edit',
        'controller' => 'App\\Http\\Controllers\\SupplierController@edit',
        'namespace' => NULL,
        'prefix' => '/supplier',
        'where' => 
        array (
        ),
        'as' => 'generated::BrKzIYqHZqVRcP0o',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::GVFQu6TyrfH918ho' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'supplier/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:MNG,ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\SupplierController@update',
        'controller' => 'App\\Http\\Controllers\\SupplierController@update',
        'namespace' => NULL,
        'prefix' => '/supplier',
        'where' => 
        array (
        ),
        'as' => 'generated::GVFQu6TyrfH918ho',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::VAF8v3Vm8zKmTFAu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'supplier/{id}/edit_ajax',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:MNG,ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\SupplierController@edit_ajax',
        'controller' => 'App\\Http\\Controllers\\SupplierController@edit_ajax',
        'namespace' => NULL,
        'prefix' => '/supplier',
        'where' => 
        array (
        ),
        'as' => 'generated::VAF8v3Vm8zKmTFAu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xnwxvBT5aVcLGWTY' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'supplier/{id}/update_ajax',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:MNG,ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\SupplierController@update_ajax',
        'controller' => 'App\\Http\\Controllers\\SupplierController@update_ajax',
        'namespace' => NULL,
        'prefix' => '/supplier',
        'where' => 
        array (
        ),
        'as' => 'generated::xnwxvBT5aVcLGWTY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gQ6QvsZWwMmHzHQs' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'supplier/{id}/delete_ajax',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:MNG,ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\SupplierController@confirm_ajax',
        'controller' => 'App\\Http\\Controllers\\SupplierController@confirm_ajax',
        'namespace' => NULL,
        'prefix' => '/supplier',
        'where' => 
        array (
        ),
        'as' => 'generated::gQ6QvsZWwMmHzHQs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2wbvypYudhg2URGM' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'supplier/{id}/delete_ajax',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:MNG,ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\SupplierController@delete_ajax',
        'controller' => 'App\\Http\\Controllers\\SupplierController@delete_ajax',
        'namespace' => NULL,
        'prefix' => '/supplier',
        'where' => 
        array (
        ),
        'as' => 'generated::2wbvypYudhg2URGM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::eaqELzAlcpZqXzj5' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'supplier/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:MNG,ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\SupplierController@destroy',
        'controller' => 'App\\Http\\Controllers\\SupplierController@destroy',
        'namespace' => NULL,
        'prefix' => '/supplier',
        'where' => 
        array (
        ),
        'as' => 'generated::eaqELzAlcpZqXzj5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::oyTbm7rHv08IYBgU' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'supplier/import',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:MNG,ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\SupplierController@import',
        'controller' => 'App\\Http\\Controllers\\SupplierController@import',
        'namespace' => NULL,
        'prefix' => '/supplier',
        'where' => 
        array (
        ),
        'as' => 'generated::oyTbm7rHv08IYBgU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::urgURUNRiYOsupLm' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'supplier/import_ajax',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:MNG,ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\SupplierController@import_ajax',
        'controller' => 'App\\Http\\Controllers\\SupplierController@import_ajax',
        'namespace' => NULL,
        'prefix' => '/supplier',
        'where' => 
        array (
        ),
        'as' => 'generated::urgURUNRiYOsupLm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::J1NzvJ7GLds0C133' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'supplier/export_excel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:MNG,ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\SupplierController@export_excel',
        'controller' => 'App\\Http\\Controllers\\SupplierController@export_excel',
        'namespace' => NULL,
        'prefix' => '/supplier',
        'where' => 
        array (
        ),
        'as' => 'generated::J1NzvJ7GLds0C133',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wj7wGAQPknYaxIa8' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'supplier/export_pdf',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'authorize:ADM',
          3 => 'authorize:MNG,ADM',
        ),
        'uses' => 'App\\Http\\Controllers\\SupplierController@export_pdf',
        'controller' => 'App\\Http\\Controllers\\SupplierController@export_pdf',
        'namespace' => NULL,
        'prefix' => '/supplier',
        'where' => 
        array (
        ),
        'as' => 'generated::wj7wGAQPknYaxIa8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'id' => '[0-9]+',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
